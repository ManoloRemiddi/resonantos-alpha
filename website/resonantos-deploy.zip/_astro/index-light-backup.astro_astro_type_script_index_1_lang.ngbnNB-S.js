import"https://cdn.jsdelivr.net/npm/gsap@3/dist/ScrollTrigger.min.js";
