import"https://cdn.jsdelivr.net/npm/lenis@1.0.42/dist/lenis.min.js";
